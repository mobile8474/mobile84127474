//
// Created by Haifa Bogdan Adnan on 30/08/2018.
//

#ifndef ARIOMINER_RUNNER_H
#define ARIOMINER_RUNNER_H

class runner {
public:
    virtual void run() = 0;
    virtual void stop() = 0;
};

#endif //ARIOMINER_RUNNER_H
