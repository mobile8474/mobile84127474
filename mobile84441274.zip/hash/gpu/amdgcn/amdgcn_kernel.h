//
// Created by Haifa Bogdan Adnan on 07.10.2018.
//

#ifndef ARIOMINER_AMDGCN_KERNEL_H
#define ARIOMINER_AMDGCN_KERNEL_H

extern string amdgcn_kernel;

#endif //ARIOMINER_AMDGCN_KERNEL_H
