//
// Created by Haifa Bogdan Adnan on 06/08/2018.
//

#ifndef ARIOMINER_OPENCL_KERNEL_H
#define ARIOMINER_OPENCL_KERNEL_H

extern string opencl_kernel;

#endif //ARIOMINER_OPENCL_KERNEL_H
