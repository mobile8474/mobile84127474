describe('SignalMessage', () => {
});
