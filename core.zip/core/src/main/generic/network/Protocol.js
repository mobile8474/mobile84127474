class Protocol {
}
Protocol.DUMB = 0;
Protocol.WSS = 1;
Protocol.RTC = 2;
Protocol.WS = 4;
Class.register(Protocol);
