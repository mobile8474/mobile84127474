class GenesisConfig {}
Class.register(GenesisConfig);
