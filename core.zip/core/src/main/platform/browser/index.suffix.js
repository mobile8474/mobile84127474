    exports._loaded = true;
    if (typeof exports._onload === 'function') exports._onload();
    return exports;
})(Nimiq);
